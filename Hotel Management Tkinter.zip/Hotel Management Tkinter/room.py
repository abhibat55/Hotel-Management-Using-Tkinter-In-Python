import tkinter.ttk
from tkinter import *
from PIL import Image,ImageTk
import mysql.connector as mysql
from tkinter import messagebox

from datetime import datetime

class Roombooking:
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel Management System")
        self.root.geometry("1195x520+250+220")
        #---- variables ----- #
        self.var_contact=StringVar()
        self.var_checkin=StringVar()
        self.var_checkout =StringVar()
        self.var_roomtype =StringVar()
        self.var_roomavailable=StringVar()
        self.var_meal=StringVar()
        self.var_noOfdays=StringVar()
        self.var_paidtax=StringVar()
        self.var_actualtotal=StringVar()
        self.var_total=StringVar()


        # ------- title -------#
        lbl_title = Label(self.root, text="ROOM BOOKING DETAILS", font=("times new roman", 18, "bold"), bg="black",
                          fg="gold", bd=4, relief=RIDGE)
        lbl_title.place(x=0, y=0, width=1395, height=50)

        # -------logo-------#
        img2 = Image.open(r"C:\Users\admin\Desktop\hotel management system\Images\Imperial-Hotel.jpg")
        img2 = img2.resize((100, 140), Image.ANTIALIAS)
        self.photoimg2 = ImageTk.PhotoImage(img2)
        lblimg = Label(self.root, image=self.photoimg2, bd=0, relief=RIDGE)
        lblimg.place(x=5, y=6, width=100, height=40)
       #------ Labels and Entry fields  ----------- #
        label_frame_left =LabelFrame(self.root, bd=2, relief=RIDGE, text="Room Booking Details",font=("times new roman", 12, "bold"), padx=2, pady=6)
        label_frame_left.place(x=5, y=50, width=425, height=450)
#------------- contact ------------- #
        lbl_cust_contact = Label(label_frame_left, text="Customer Contact", font=("times new roman", 12, "bold"), padx=2,pady=6)
        lbl_cust_contact.grid(row=0, column=0, sticky=W)
        entry_contact=Entry(label_frame_left,width=23, font=("arial", 10, "bold"),textvariable=self.var_contact)
        entry_contact.grid(row=0, column=1,padx=4,sticky=W)
#-- fetchdata Button --#
        btnFetchData=Button(label_frame_left,text="Fetch Data",command=self.fetch_contact,font=("arial",9,"bold"),bg="black",fg="gold",width=8)
        btnFetchData.place(x=342,y=4)

#------------ check-in-date-------------#
        check_in_date= Label(label_frame_left, text="Check-in-date", font=("times new roman", 12, "bold"),padx=2, pady=6)
        check_in_date.grid(row=1, column=0, sticky=W)
        entry_check_in_date = Entry(label_frame_left, width=29, font=("arial", 10, "bold"),textvariable=self.var_checkin)
        entry_check_in_date.grid(row=1, column=1, padx=4,pady=1)
#-------------check-out-date--------#
        check_out_date = Label(label_frame_left, text="Check-out-date", font=("times new roman", 12, "bold"), padx=2,pady=6)
        check_out_date.grid(row=2, column=0, sticky=W)
        entry_check_out_date = Entry(label_frame_left, width=29, font=("arial", 10, "bold"),textvariable=self.var_checkout)
        entry_check_out_date.grid(row=2, column=1, padx=4,pady=1)
#--------Room Type---------- #
        label_RoomType=Label(label_frame_left, text="Room Type", font=("times new roman", 12, "bold"), padx=2,pady=6)
        label_RoomType.grid(row=3, column=0, sticky=W)
        combo_RoomType=tkinter.ttk.Combobox(label_frame_left,textvariable=self.var_roomtype,font=("times new roman", 12, "bold"),width=24,state="readonly")

        con = mysql.connect(user="root", password="root", host="localhost", database="hotel")
        cur = con.cursor()
        cur.execute("select RoomType from details")
        roomtype_data = cur.fetchall()

        combo_RoomType["value"]=roomtype_data
        combo_RoomType.current(0)
        combo_RoomType.grid(row=3,column=1,pady=1)
#------ Available Room ---- #
        lblRoomAvailable=Label(label_frame_left,text="Available Rooms",font=("times new roman", 12, "bold"))
        lblRoomAvailable.grid(row=4,column=0,sticky=W)


        con = mysql.connect(user="root", password="root", host="localhost", database="hotel")
        cur = con.cursor()
        cur.execute("select RoomNo from details")
        data = cur.fetchall()

        combo_RoomNo = tkinter.ttk.Combobox(label_frame_left, textvariable=self.var_roomavailable,font=("times new roman", 12, "bold"), width=24, state="readonly")
        combo_RoomNo["value"] =data
        combo_RoomNo.current(0)
        combo_RoomNo.grid(row=4,column=1, pady=1)

#------- Meal -------- #
        lblMeal=Label(label_frame_left, text="Meal", font=("times new roman", 12, "bold"), padx=2,pady=6)
        lblMeal.grid(row=5,column=0,sticky=W)
        entry_Meal=Entry(label_frame_left,width=29,font=("arial",10,"bold"),textvariable=self.var_meal)
        entry_Meal.grid(row=5,column=1,pady=1)

#------- No of Days ------- #
        lblNoOfdays=Label(label_frame_left,text="No of days",font=("times new roman", 12, "bold"))
        lblNoOfdays.grid(row=6,column=0,sticky=W)
        entry_NoOfdays=Entry(label_frame_left,width=29,font=('arial',10,'bold'),textvariable=self.var_noOfdays)
        entry_NoOfdays.grid(row=6,column=1,pady=1)

#-------- Paid Tax ------- #
        lblPaidtax=Label(label_frame_left,text="Paid Tax",font=("times new roman", 12, "bold"))
        lblPaidtax.grid(row=7,column=0,sticky=W)
        entry_Paidtax=Entry(label_frame_left,width=29,font=('arial',10,'bold'),textvariable=self.var_paidtax)
        entry_Paidtax.grid(row=7,column=1,pady=1)


#------- Subtotal -------- #
        lblSubtotal=Label(label_frame_left,text="Subtotal",font=("times new roman", 12, "bold"))
        lblSubtotal.grid(row=8,column=0,sticky=W)
        entry_Subtotal=Entry(label_frame_left,width=29,font=('arial',10,'bold'),textvariable=self.var_actualtotal)
        entry_Subtotal.grid(row=8,column=1,pady=1)

#----- Totoal cost ------ #
        lblTotalcost=Label(label_frame_left,text="Total Cost",font=("times new roman", 12, "bold"))
        lblTotalcost.grid(row=9,column=0,sticky=W)
        entry_Totalcost=Entry(label_frame_left,width=29,font=('arial',10,'bold'),textvariable=self.var_total)
        entry_Totalcost.grid(row=9, column=1,pady=1)

#---------- Bill Button ------- #
        btn_Bill =Button(label_frame_left, text="Bill", font=("arial", 12, "bold"), bg="black", fg="gold", width=9,command=self.total)
        btn_Bill.grid(row=10, column=0, padx=1,sticky=W)


#------- button Frame ------- #
        btn_frame = Frame(label_frame_left, bd=2, relief=RIDGE)
        btn_frame.place(x=0, y=350, width=412, height=40)
        btn_Add = Button(btn_frame, text="Add", font=("arial", 12, "bold"), bg="black", fg="gold", width=9,command=self.add_data)
        btn_Add.grid(row=0, column=0, padx=1)
        btn_update = Button(btn_frame, text="Update", font=("arial", 12, "bold"), bg="black", fg="gold", width=9,command=self.update)
        btn_update.grid(row=0, column=1, padx=1)
        btn_Delete = Button(btn_frame, text="Delete", font=("arial", 12, "bold"), bg="black", fg="gold", width=9,command=self.mDelete)
        btn_Delete.grid(row=0, column=2, padx=1)
        btn_Reset = Button(btn_frame, text="Reset", font=("arial", 12, "bold"), bg="black", fg="gold", width=9,command=self.reset)
        btn_Reset.grid(row=0, column=3, padx=1)
        #------ RightSide Image ------ #
        img3 = Image.open(r"C:\Users\admin\Desktop\hotel management system\Images\3.jpg")
        img3 = img3.resize((600,220),Image.ANTIALIAS)
        self.photoimg3 = ImageTk.PhotoImage(img3)
        lblimg = Label(self.root,image=self.photoimg3,bd=0,relief=RIDGE)
        lblimg.place(x=760,y=53, width=600,height=220)

        # ------ table frame seacrh system-------
        Table_Frame = LabelFrame(self.root, bd=2, relief=RIDGE, text="View Details",font=("times new roman", 14, "bold"), padx=2, pady=6)
        Table_Frame.place(x=435, y=280, width=860, height=260)
        # -------- Show data Table ------- #
        details_table = Frame(Table_Frame, bd=2, relief=RIDGE)
        details_table.place(x=0, y=20, width=760, height=180)

        scroll_x = tkinter.ttk.Scrollbar(details_table, orient=HORIZONTAL)
        scroll_y = tkinter.ttk.Scrollbar(details_table, orient=VERTICAL)

        self.room_Table = tkinter.ttk.Treeview(details_table, column=("contact","checkin","checkout","roomtype","roomavailable","meal","noOfdays",),xscrollcommand=scroll_x.set, yscrollcommand=scroll_y.set)


        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)

        scroll_x.config(command=self.room_Table.xview)
        scroll_y.config(command=self.room_Table.yview)

        self.room_Table.heading("contact", text="Contact")
        self.room_Table.heading("checkin", text="Check-in")
        self.room_Table.heading("checkout", text="Check-out")
        self.room_Table.heading("roomtype", text="Room Type")
        self.room_Table.heading("roomavailable", text="Room No")
        self.room_Table.heading("meal", text="Meal")
        self.room_Table.heading("noOfdays", text="NoOfDays")


        self.room_Table["show"] = "headings"
        self.room_Table.column("contact", width=100)
        self.room_Table.column("checkin", width=100)
        self.room_Table.column("checkout", width=100)
        self.room_Table.column("roomtype", width=100)
        self.room_Table.column("roomavailable", width=100)
        self.room_Table.column("meal", width=100)
        self.room_Table.column("noOfdays", width=100)

        self.room_Table.pack(fill=BOTH, expand=1)
        self.room_Table.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetchdata()

#-------- add data ----------
    def add_data(self):
        if self.var_contact.get() == "" or self.var_checkin.get == "":
            messagebox.showerror("Error", "All Fields are required", parent=self.root)
        else:
            try:
                con = mysql.connect(user="root", password="root", host="localhost", database="hotel")
                cur = con.cursor()
                cur.execute("insert into room values(%s,%s,%s,%s,%s,%s,%s)",(self.var_contact.get(),
                                                                                 self.var_checkin.get(),
                                                                                 self.var_checkout.get(),
                                                                                 self.var_roomtype.get(),
                                                                                 self.var_roomavailable.get(),
                                                                                 self.var_meal.get(),
                                                                                 self.var_noOfdays.get()))




                con.commit()
                self.fetchdata()
                con.close()
                messagebox.showinfo("Success", "Room Booked", parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning", f"Something went wrong:{str(es)}", parent=self.root)

    def fetchdata(self):
        con = mysql.connect(user="root", password="root", host="localhost", database="hotel")
        cur = con.cursor()
        cur.execute("select * from room")
        data = cur.fetchall()
        if len(data)!= 0:
            self.room_Table.delete(*self.room_Table.get_children())
            for i in data:
                self.room_Table.insert("", END, values=i)
            con.commit()
            con.close()


    def get_cursor(self,event=""):
        cursor_row=self.room_Table.focus()
        content=self.room_Table.item(cursor_row)
        row=content["values"]
        self.var_contact.set(row[0]),
        self.var_checkin.set(row[1]),
        self.var_checkout.set(row[2]),
        self.var_roomtype.set(row[3]),
        self.var_roomavailable.set(row[4]),
        self.var_meal.set(row[5]),
        self.var_noOfdays.set(row[6])

    def update(self):
        if self.var_contact.get() == "":
            messagebox.showerror("Error", "Please enter Contact details", parent=self.root)
        else:
            con = mysql.connect(user="root", password="root", host="localhost", database="hotel")
            cur = con.cursor()
            cur.execute("update room set check_in=%s,check_out=%s,roomtype=%s,roomavailable=%s,meal=%s,noOfdays=%s,where Contact=%s",(self.var_checkin.get(),
                                                                                                                                      self.var_checkout.get(),
                                                                                                                                      self.var_roomtype.get(),
                                                                                                                                      self.var_roomavailable.get(),
                                                                                                                                      self.var_meal.get(),
                                                                                                                                      self.var_noOfdays.get(),
                                                                                                                                      self.var_contact.get()))






            con.commit()
            self.fetchdata()
            con.close()
            messagebox.showinfo("Update", "Room Details Updated Successfully", parent=self.root)
    def mDelete(self):
        global mycon
        mDelete=messagebox.askyesno("Hotel Management System","Do You Want delete this Room Details",parent=self.root)
        if mDelete>0:
            mycon =mysql.connect(user="root", password="root", host="localhost", database="hotel")
            cur=mycon.cursor()
            query="delete from room where Contact=%s"
            value=(self.var_contact.get(),)
            cur.execute(query,value)

        else:
            if not mDelete:
                return
        mycon.commit()
        self.fetchdata()
        mycon.close()

    def reset(self):
        self.var_contact.set("")
        self.var_checkin.set(""),
        self.var_checkout.set(""),
        self.var_roomtype.set(""),
        self.var_meal.set("")
        self.var_noOfdays.set("")
        self.var_paidtax.set("")
        self.var_actualtotal.set("")
        self.var_total.set("")




#--------------- fetch all data in frame ----------- #
    def fetch_contact(self):
        if self.var_contact.get()=="":
            messagebox.showerror("Error","Please enter Contact Number",parent=self.root)
        else:
            conn = mysql.connect(user="root", password="root", host="localhost", database="hotel")
            cur = conn.cursor()
            query=("select Name from customer where Contact=%s")
            value=(self.var_contact.get(),)
            cur.execute(query,value)
            row=cur.fetchone()

            if row==None:
                messagebox.showerror("Error","This Number Not Found",parent=self.root)
            else:
                conn.commit()
                conn.close()

                showDataframe=Frame(self.root,bd=4,relief=RIDGE,padx=2)
                showDataframe.place(x=455,y=55,width=300,height=180)

                lblName=Label(showDataframe,text="Name:",font=("arial",12,"bold"))
                lblName.place(x=0,y=0)

                lbl=Label(showDataframe,text=row,font=("arial",12,"bold"))
                lbl.place(x=90,y=0)

                #------- Gender ------- #
                conn = mysql.connect(user="root", password="root", host="localhost", database="hotel")
                cur = conn.cursor()
                query = ("select Gender from customer where Contact=%s")
                value = (self.var_contact.get(),)
                cur.execute(query, value)
                row = cur.fetchone()
                lblGender = Label(showDataframe, text="Gender:", font=("arial", 12, "bold"))
                lblGender.place(x=0,y=30)

                lbl2=Label(showDataframe,text=row,font=("arial", 12, "bold"))
                lbl2.place(x=90, y=30)

                #------- Email ------ #
                conn = mysql.connect(user="root", password="root", host="localhost", database="hotel")
                cur = conn.cursor()
                query = ("select Email from customer where Contact=%s")
                value = (self.var_contact.get(),)
                cur.execute(query, value)
                row = cur.fetchone()
                lblemail =Label(showDataframe, text="Email:", font=("arial", 12, "bold"))
                lblemail.place(x=0, y=60)

                lbl3= Label(showDataframe, text=row, font=("arial", 12, "bold"))
                lbl3.place(x=90, y=60)

                #------- Nationality ------- #
                conn = mysql.connect(user="root", password="root", host="localhost", database="hotel")
                cur = conn.cursor()
                query = ("select Nationality from customer where Contact=%s")
                value = (self.var_contact.get(),)
                cur.execute(query, value)
                row = cur.fetchone()
                lblnationality =Label(showDataframe, text="Nationality:", font=("arial", 12, "bold"))
                lblnationality.place(x=0,y=90)

                lbl4=Label(showDataframe, text=row,font=("arial", 12, "bold"))
                lbl4.place(x=90,y=90)
                #------ Address ---- #
                conn = mysql.connect(user="root", password="root", host="localhost", database="hotel")
                cur = conn.cursor()
                query = ("select Address from customer where Contact=%s")
                value = (self.var_contact.get(),)
                cur.execute(query, value)
                row = cur.fetchone()
                lbladdress = Label(showDataframe, text="Address:", font=("arial", 12, "bold"))
                lbladdress.place(x=0, y=120)

                lbl5 = Label(showDataframe, text=row, font=("arial", 12, "bold"))
                lbl5.place(x=90, y=120)
    def total(self):
        inDate=self.var_checkin.get()
        outDate=self.var_checkout.get()
        inDate=datetime.strptime(inDate,"%d/%m/%Y")
        outDate =datetime.strptime(outDate,"%d/%m/%Y")
        self.var_noOfdays.set(abs(outDate-inDate).days)

        if (self.var_meal.get()=="Breakfast" and self.var_roomtype.get()=="Luxury"):
            q1=float(300)
            q2=float(700)
            q3=float(self.var_noOfdays.get())
            q4=float(q1+q2)
            q5=(q3+q4)
            Tax="Rs."+str("%.2f"%((q5)*0.09))
            ST="Rs."+str("%.2f"%((q5)))
            TT="Rs."+str("%.2f"%((q5+(q5)*0.09)))
            self.var_paidtax.set(Tax)
            self.var_actualtotal.set(ST)
            self.var_total.set(TT)

        elif (self.var_meal.get() == "Dinner" and self.var_roomtype.get() == "Single"):
            q1 = float(300)
            q2 = float(700)
            q3 = float(self.var_noOfdays.get())
            q4 = float(q1 + q2)
            q5 =(q3+q4)
            Tax = "Rs." +str("%.2f" % ((q5) * 0.09))
            ST = "Rs." + str("%.2f" % ((q5)))
            TT = "Rs." + str("%.2f" % ((q5 + (q5) * 0.09)))
            self.var_paidtax.set(Tax)
            self.var_actualtotal.set(ST)
            self.var_total.set(TT)

        elif (self.var_meal.get() == "Breakfast" and self.var_roomtype.get() == "Double"):
            q1 = float(300)
            q2 = float(900)
            q3 = float(self.var_noOfdays.get())
            q4 = float(q1 + q2)
            q5 = (q3 + q4)
            Tax = "Rs." + str("%.2f" % ((q5) * 0.09))
            ST = "Rs." + str("%.2f" % ((q5)))
            TT = "Rs." + str("%.2f" % ((q5 + (q5) * 0.09)))
            self.var_paidtax.set(Tax)
            self.var_actualtotal.set(ST)
            self.var_total.set(TT)

        elif (self.var_meal.get() == "Breakfast" and self.var_roomtype.get() == "Duplex"):
            q1 = float(300)
            q2 = float(1400)
            q3 = float(self.var_noOfdays.get())
            q4 = float(q1 + q2)
            q5 = (q3 + q4)
            Tax = "Rs." + str("%.2f" % ((q5) * 0.09))
            ST = "Rs." + str("%.2f" % ((q5)))
            TT = "Rs." + str("%.2f" % ((q5 + (q5) * 0.09)))
            self.var_paidtax.set(Tax)
            self.var_actualtotal.set(ST)
            self.var_total.set(TT)


if __name__ == '__main__':
    root=Tk()
    obj=Roombooking(root)
    root.mainloop()

