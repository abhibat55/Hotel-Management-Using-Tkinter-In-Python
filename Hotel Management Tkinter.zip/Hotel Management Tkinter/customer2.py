import tkinter.ttk
from tkinter import *
from PIL import Image,ImageTk
import mysql.connector as mysql
import random
from tkinter import messagebox


class Cust_win:
    def __init__(self,root):
        self.root=root
        self.root.title("Customer Details")
        self.root.geometry("1195x520+250+220")

        #------- variables -------- #
        self.var_ref=StringVar()
        x=random.randint(1000,9999)
        self.var_ref.set(str(x))

        self.var_cust_name=StringVar()
        self.var_gender=StringVar()
        self.var_contact=StringVar()
        self.var_email=StringVar()
        self.var_nationality=StringVar()
        self.var_id_proof=StringVar()
        self.var_id_proof_no=StringVar()
        self.var_address=StringVar()



    #------- title -------#
        lbl_title=Label(self.root,text="ADD CUSTOMER DETAILS",font=("times new roman",18,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE)
        lbl_title.place(x=0,y=0,width=1395,height=50)

    #-------logo-------#
        img2 = Image.open(r"C:\Users\admin\Desktop\hotel management system\Images\Imperial-Hotel.jpg")
        img2 = img2.resize((100, 140), Image.ANTIALIAS)
        self.photoimg2 = ImageTk.PhotoImage(img2)
        lblimg = Label(self.root, image=self.photoimg2, bd=0, relief=RIDGE)
        lblimg.place(x=5, y=6, width=100, height=40)
    #------ Label Frame ------- #
        label_frame_left=LabelFrame(self.root,bd=2,relief=RIDGE,text="Customer Details",font=("times new roman",12,"bold"),padx=2,pady=6)
        label_frame_left.place(x=5,y=50,width=425,height=450)
        #------- labels and entry field ----- #

        #--- cust_ref
        lbl_cust_ref=Label(label_frame_left,text="Customer Ref",font=("times new roman",12,"bold"),padx=2,pady=6)
        lbl_cust_ref.grid(row=0,column=0,sticky=W)
        entry_ref=Entry(label_frame_left,textvariable=self.var_ref,width=29,font=("arial", 10,"bold"),state="readonly")
        entry_ref.grid(row=0,column=1,padx=4)
        # cust_name
        cname = Label(label_frame_left, text="Customer Name", font=("arial", 12, "bold"),padx=2,pady=6)
        cname.grid(row=1, column=0, sticky=W)
        entry_cname = Entry(label_frame_left,textvariable=self.var_cust_name, width=29,font=("arial", 10,"bold"))
        entry_cname.grid(row=1, column=1, padx=4)
        #gender combo
        lbl_gender = Label(label_frame_left, text="Gender", font=("arial", 12, "bold"),padx=2,pady=6)
        lbl_gender.grid(row=2, column=0, sticky=W)
        combo_gender=tkinter.ttk.Combobox(label_frame_left,textvariable=self.var_gender,width=26,state="readonly",font=("arial", 10,"bold"))
        combo_gender["value"]=("Male","Female","Other")
        combo_gender.current(0)
        combo_gender.grid(row=2,column=1)


        #------- Contact------
        lbl_contact = Label(label_frame_left, text="Contact No", font=("arial", 12, "bold"),padx=2,pady=6)
        lbl_contact.grid(row=3, column=0, sticky=W)
        entry_contact = Entry(label_frame_left,textvariable=self.var_contact, width=29,font=("arial", 10,"bold"))
        entry_contact.grid(row=3, column=1, padx=4)
        #------ E-mail------
        lbl_email = Label(label_frame_left, text="E-mail", font=("arial", 12, "bold"),padx=2,pady=6)
        lbl_email.grid(row=4, column=0, sticky=W)
        entry_email = Entry(label_frame_left, width=29,textvariable=self.var_email,font=("arial", 10,"bold"))
        entry_email.grid(row=4, column=1, padx=4)
        #---- nationality

        lbl_nationality = Label(label_frame_left, text="Nationality", font=("arial", 12, "bold"),padx=2,pady=6)
        lbl_nationality.grid(row=5, column=0, sticky=W)
        combo_nationality = tkinter.ttk.Combobox(label_frame_left,textvariable=self.var_nationality, width=26, state="readonly", font=("arial", 10, "bold"))
        combo_nationality["value"] = ("Indian", "American","Britian")
        combo_nationality.current(0)
        combo_nationality.grid(row=5, column=1)

        #----- id proof type combobox
        lbl_idproof=Label(label_frame_left, text="ID-Proof Type", font=("arial", 12, "bold"),padx=2,pady=6)
        lbl_idproof.grid(row=6, column=0, sticky=W)
        combo_id = tkinter.ttk.Combobox(label_frame_left,textvariable=self.var_id_proof, width=26, state="readonly",font=("arial", 10, "bold"))
        combo_id["value"] = ("Aadhaar-Card", "Driving License", "Passport")
        combo_id.current(0)
        combo_id.grid(row=6, column=1)




        #---id proof number

        lbl_id_number = Label(label_frame_left, text="ID-Proof No", font=("arial", 12, "bold"),padx=2,pady=6)
        lbl_id_number.grid(row=7, column=0, sticky=W)
        entry_id_number = Entry(label_frame_left,textvariable=self.var_id_proof_no,width=29,font=("arial", 10,"bold"))
        entry_id_number.grid(row=7, column=1, padx=4)

        #------- address -------
        lbl_address = Label(label_frame_left, text="Address", font=("arial", 12, "bold"),padx=2,pady=6)
        lbl_address.grid(row=8, column=0, sticky=W)
        entry_address = Entry(label_frame_left,textvariable=self.var_address, width=29,font=("arial", 10,"bold"))
        entry_address.grid(row=8, column=1, padx=4)
        #--------- buttons ------- #
        btn_frame=Frame(label_frame_left,bd=2,relief=RIDGE)
        btn_frame.place(x=0,y=350,width=412,height=40)

        btn_Add=Button(btn_frame,text="Add",font=("arial",12,"bold"),bg="black",fg="gold",width=9,command=self.add_data)
        btn_Add.grid(row=0,column=0,padx=1)
        btn_update = Button(btn_frame, text="Update", font=("arial", 12, "bold"), bg="black", fg="gold",width=9,command=self.update)
        btn_update.grid(row=0, column=1,padx=1)
        btn_Delete = Button(btn_frame, text="Delete", font=("arial", 12, "bold"), bg="black", fg="gold", width=9,command=self.mDelete)
        btn_Delete.grid(row=0, column=2, padx=1)
        btn_Reset = Button(btn_frame, text="Reset", font=("arial", 12, "bold"), bg="black", fg="gold", width=9,command=self.reset)
        btn_Reset.grid(row=0, column=3, padx=1)

        #------ table frame seacrh system-------
        Table_Frame= LabelFrame(self.root, bd=2, relief=RIDGE, text="View Details",font=("times new roman", 14, "bold"), padx=2, pady=6)
        Table_Frame.place(x=435, y=50, width=860, height=520)







        #-------- Show data Table ------- #
        details_table=Frame(Table_Frame,bd=2,relief=RIDGE)
        details_table.place(x=0,y=50,width=860,height=350)

        scroll_x=tkinter.ttk.Scrollbar(details_table,orient=HORIZONTAL)
        scroll_y = tkinter.ttk.Scrollbar(details_table, orient=VERTICAL)

        self.Cust_Details_Table=tkinter.ttk.Treeview(details_table,column=("ref","name","gender","contact","email","nationality","idproof","idnumber","address"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.Cust_Details_Table.xview)
        scroll_y.config(command=self.Cust_Details_Table.yview)

        self.Cust_Details_Table.heading("ref",text="Ref No")
        self.Cust_Details_Table.heading("name", text="Name")
        self.Cust_Details_Table.heading("gender", text="Gender")
        self.Cust_Details_Table.heading("contact", text="Contact")
        self.Cust_Details_Table.heading("email", text="Email")
        self.Cust_Details_Table.heading("nationality", text="Nationality")
        self.Cust_Details_Table.heading("idproof", text="Id Proof")
        self.Cust_Details_Table.heading("idnumber", text="Id Number")
        self.Cust_Details_Table.heading("address", text="Address")

        self.Cust_Details_Table["show"]="headings"
        self.Cust_Details_Table.column("ref",width=100)
        self.Cust_Details_Table.column("name", width=100)
        self.Cust_Details_Table.column("gender", width=100)
        self.Cust_Details_Table.column("contact", width=100)
        self.Cust_Details_Table.column("email", width=100)
        self.Cust_Details_Table.column("nationality", width=100)
        self.Cust_Details_Table.column("idproof", width=100)
        self.Cust_Details_Table.column("idnumber", width=100)
        self.Cust_Details_Table.pack(fill=BOTH,expand=1)
        self.Cust_Details_Table.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetchdata()
    def add_data(self):
        if self.var_contact.get()=="" or self.var_email.get=="":
            messagebox.showerror("Error","All Fields are required",parent=self.root)
        else:
            try:
                con=mysql.connect(user="root",password="root",host="localhost",database="hotel")
                cur=con.cursor()
                cur.execute("insert into customer values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",(self.var_ref.get(),
                                                                                       self.var_cust_name.get(),
                                                                                       self.var_gender.get(),
                                                                                       self.var_contact.get(),
                                                                                       self.var_email.get(),
                                                                                       self.var_nationality.get(),
                                                                                       self.var_id_proof.get(),
                                                                                       self.var_id_proof_no.get(),
                                                                                       self.var_address.get()))
                con.commit()
                self.fetchdata()
                con.close()
                messagebox.showinfo("Success","Customer added successfully",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning",f"Something went wrong:{str(es)}",parent=self.root)

    def fetchdata(self):
        con = mysql.connect(user="root", password="root", host="localhost", database="hotel")
        cur = con.cursor()
        cur.execute("select * from customer")
        data=cur.fetchall()
        if len(data)!=0:
            self.Cust_Details_Table.delete(*self.Cust_Details_Table.get_children())
            for i in data:
                self.Cust_Details_Table.insert("",END,values=i)
            con.commit()
        con.close()
    def get_cursor(self,event):
        cursor_row=self.Cust_Details_Table.focus()
        content=self.Cust_Details_Table.item(cursor_row)
        row=content["values"]

        self.var_ref.set(row[0]),
        self.var_cust_name.set(row[1]),
        self.var_gender.set(row[2]),
        self.var_contact.set(row[3]),
        self.var_email.set(row[4]),
        self.var_nationality.set(row[5]),
        self.var_id_proof.set(row[6]),
        self.var_id_proof_no.set(row[7]),
        self.var_address.set(row[8])


    def update(self):
        if self.var_contact.get()=="":
            messagebox.showerror("Error","Please enter Contact details",parent=self.root)
        else:
            con =mysql.connect(user="root", password="root", host="localhost", database="hotel")
            cur =con.cursor()
            cur.execute("update customer set Name=%s,Gender=%s,Contact=%s,Email=%s,Nationality=%s,Idproof=%s,Idnumber=%s,Address=%s where Ref=%s",(self.var_cust_name.get(),
                                                                                                                                                   self.var_gender.get(),
                                                                                                                                                   self.var_contact.get(),
                                                                                                                                                   self.var_email.get(),
                                                                                                                                                   self.var_nationality.get(),
                                                                                                                                                   self.var_id_proof.get(),
                                                                                                                                                   self.var_id_proof_no.get(),
                                                                                                                                                   self.var_address.get(),
                                                                                                                                                   self.var_ref.get()))
            con.commit()
            self.fetchdata()
            con.close()
            messagebox.showinfo("Update","Customer Details updated Successfully",parent=self.root)

    def mDelete(self):
        global mycon
        mDelete=messagebox.askyesno("Hotel Management System","Do You Want delete this customer",parent=self.root)
        if mDelete>0:
            mycon =mysql.connect(user="root", password="root", host="localhost", database="hotel")
            cur=mycon.cursor()
            query="delete from customer where Ref=%s"
            value=(self.var_ref.get(),)
            cur.execute(query,value)


        else:
            if not mDelete:
                return
        mycon.commit()
        self.fetchdata()
        mycon.close()
    def reset(self):
        self.var_ref.set("")
        self.var_cust_name.set(""),
        self.var_contact.set(""),
        self.var_email.set(""),
        self.var_id_proof_no.set("")
        self.var_address.set("")

        x = random.randint(1000, 9999)
        self.var_ref.set(str(x))















if __name__ == '__main__':
    root=Tk()
    obj=Cust_win(root)
    root.mainloop()